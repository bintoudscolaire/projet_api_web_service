import Server from './src/server.mjs';

const server = new Server();

server.run();
