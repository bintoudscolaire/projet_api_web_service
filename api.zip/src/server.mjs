import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import compression from 'compression';
import cors from 'cors';
import helmet from 'helmet';

import config from './config.mjs';
import Users from './controllers/routes.mjs';

class Server {
  constructor() {
    this.app = express();
    this.config = config.development;
  }

  async dbConnect() {
    try {
      await mongoose.connect(this.config.mongodb);
      console.log('[CONNECTED] MongoDB connecté');
    } catch (err) {
      console.error('[ERROR] MongoDB', err);
      process.exit(1);
    }
  }

  middleware() {
    this.app.use(compression());
    this.app.use(cors());
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: true }));
  }

  routes() {
    new Users(this.app);

    this.app.use((req, res) => {
      res.status(404).json({
        code: 404,
        message: 'Not Found'
      });
    });
  }

  security() {
    this.app.use(helmet());
    this.app.disable('x-powered-by');
  }

  async run() {
    await this.dbConnect();
    this.security();
    this.middleware();
    this.routes();

    this.app.listen(this.config.port, () => {
      console.log(`[SERVER] Listening on port ${this.config.port}`);
    });
  }
}

export default Server;
