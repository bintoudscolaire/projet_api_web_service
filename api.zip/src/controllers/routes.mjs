import express from 'express';
import User from '../models/user.mjs';

export default class Users {
  constructor(app) {
    const router = express.Router();

    // GET /users
    router.get('/', async (req, res) => {
      try {
        const users = await User.find();
        return res.json(users);
      } catch (err) {
        console.error('[GET /users]', err);
        return res.status(500).json({ error: 'Erreur serveur' });
      }
    });

    // PATCH /users/:id
    router.patch('/:id', async (req, res) => {
      try {
        const updatedUser = await User.findByIdAndUpdate(
          req.params.id,
          { $set: req.body },
          { new: true }
        );

        if (!updatedUser) {
          return res.status(404).json({ error: 'Utilisateur non trouvé' });
        }

        return res.json(updatedUser);
      } catch (err) {
        console.error('[PATCH /users]', err);
        return res.status(400).json({ error: 'Requête invalide' });
      }
    });

    app.use('/users', router);
  }
}
