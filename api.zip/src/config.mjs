export default {
  development: {
    type: 'development',
    port: 3000,
    mongodb: 'mongodb://localhost:27017/api-tp1'   // URL locale
  },
  production: {
    type: 'production',
    port: 3000,
    mongodb: 'mongodb://localhost:27017/api-tp1'   // (facultatif ici mais bon à faire)
  }
};
